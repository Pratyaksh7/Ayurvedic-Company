<div class="container-fluid footer-background" align="center" >
    <div class="row">
        <div class="col-md-4" >
             <!-- Contact Us Information here -->
             <h4>Contact</h4>
            <div class="w3-col s4 ">
                
                <div class="row" >
                        <div class="col-md-1">
                            <i class="fa fa-fw fa-map-marker"></i>
                        </div>
                        <!-- <div class="col-md-3"> -->
                        <p class="center" style="font-size:14px;"> Regd. Office: 01, village-Badwai, Teh-Dungla,
                             Distt-Chittorgarh (Raj.)</p>
                        <!-- </div> -->
                    </div>
                    <div class="row">
                        <div class="col-md-1">
                            <i class="fa fa-fw fa-map-marker"></i> 
                        </div>
                        <!-- <div class="col-md-3"> -->
                            <p class="center">Corp. Office: 324, B-Block Pratap Nagar, Udaipur (Raj.)</p>
                        <!-- </div> -->
                    </div>
                    <div class="row">
                        <div class="col-md-1">
                            <i class="fa fa-fw fa-phone"></i>
                        </div>
                        <!-- <div class="col-md-3"> -->
                        <p class="center"> 742-600-6424</p> 
                        <!-- </div> -->
                    </div>
                    <div class="row">
                        <div class="col-md-1">
                         <i class="fa fa-fw fa-envelope"></i>
                        </div>
                        <!-- <div class="col-md-3"> -->
                        <p class="center"> hiyaayucare@gmail.com</p> 
                        <!-- </div> -->
                    </div>
                
             </div>
             
        </div>
        <div class="col-md-4" >
            <!-- Social Links here -->
            <h4>Follow us on</h4>
            <div class="navbar navbar-expand-lg navbar-light">
                <ul class="navbar-nav" style="margin-left:35%;">
                    <li class="nav-item"><a href="https://www.facebook.com/HiyaAyucareUdaipur/" class="nav-link"><i class="fa fa-fw fa-facebook-official w3-hover-opacity"></i></a></li>
                    <li class="nav-item"><a href="https://www.instagram.com/hiyaayucare/" class="nav-link"><i class="fa fa-fw fa-instagram w3-hover-opacity"></i></a></li>
                    <!-- <li class="nav-item"><a href="#" class="nav-link"><i class="fa fa-fw fa-youtube w3-hover-opacity"></i></a></li> -->
                    <li class="nav-item"><a href="https://twitter.com/HAyucare" class="nav-link"><i class="fa fa-fw fa-twitter w3-hover-opacity"></i></a></li>
                    <li class="nav-item"><a href="https://www.linkedin.com/company/31022231/admin/" class="nav-link"><i class="fa fa-fw fa-linkedin w3-hover-opacity"></i></a></li>
                </ul>
            </div>   
        </div>
        <div class="col-md-4 mb-3">
            <!-- Map here -->
            <h4>Get in Touch</h4>
            <div>
                <img src="<?= base_url('assets/images/map.jpeg') ?>" alt="map" style="width:75%; height:auto;">
            </div>

        </div>
    </div>
</div>


</body>
</html>