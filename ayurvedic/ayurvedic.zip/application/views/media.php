<div class="container-fluid">
    <div class="jumbotron" id="container1">
        <h2 align="center" style=" font-family:Castellar; color:white;">MEDIA</h2>
    </div>
</div>

<div class="container" id="media">
    <div class="row">
        <div class="col-md-4">
            <img src="<?= base_url('assets/images/logo3.png') ?>" alt="" style="width:100%">
        </div>
        <div class="col-md-4">
            <img src="<?= base_url('assets/images/logo3.png') ?>" alt="" style="width:100%">
        </div>
        <div class="col-md-4">
            <img src="<?= base_url('assets/images/logo3.png') ?>" alt="" style="width:100%">
        </div>
    </div>

    <div class="row">
        <div class="col-md-4">
            <img src="<?= base_url('assets/images/logo3.png') ?>" alt="" style="width:100%">
        </div>
        <div class="col-md-4">
            <img src="<?= base_url('assets/images/logo3.png') ?>" alt="" style="width:100%">
        </div>
        <div class="col-md-4">
            <img src="<?= base_url('assets/images/logo3.png') ?>" alt="" style="width:100%">
        </div>
    </div>

    <div class="row">
        <div class="col-md-4">
            <img src="<?= base_url('assets/images/logo3.png') ?>" alt="" style="width:100%">
        </div>
        <div class="col-md-4">
            <img src="<?= base_url('assets/images/logo3.png') ?>" alt="" style="width:100%">
        </div>
        <div class="col-md-4">
            <img src="<?= base_url('assets/images/logo3.png') ?>" alt="" style="width:100%">
        </div>
    </div>
</div>
<hr>

<?php include_once('footer.php'); ?>